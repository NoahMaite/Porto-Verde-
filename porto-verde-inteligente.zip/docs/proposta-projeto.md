# Proposta de Projeto - Porto Verde Inteligente

Desenvolver um sistema de monitoramento ambiental com sensores e IA para coleta e exibição de dados de qualidade do ar, ruído e vazamentos no Porto de Santos.