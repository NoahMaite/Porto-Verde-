# 🌿 Porto Verde Inteligente

## 📘 Sobre o projeto
O **Porto Verde Inteligente** é uma proposta desenvolvida para o **ESG Challenge 2025**, com o objetivo de monitorar a qualidade ambiental e promover a Justiça Climática na região do Porto de Santos.

O sistema utiliza **IoT, dados públicos e dashboards interativos** para fornecer informações em tempo real sobre qualidade do ar, ruído e vazamentos, aproximando a tecnologia da comunidade local.

---

## ⚙️ Tecnologias utilizadas
- HTML, CSS e JavaScript (interface)
- Python (API e análise de dados)
- Flask (servidor web)
- Pandas e Matplotlib (visualização)
- JSON / CSV (dados simulados)

---

## 📁 Estrutura do repositório
```
docs/        → Documentação e relatórios
frontend/    → Protótipo da interface
backend/     → Servidor e simulação de sensores
data/        → Dados de exemplo e análises
```

---

## 🚀 Como rodar localmente
1. Clone este repositório:
   ```bash
   git clone https://github.com/seuusuario/porto-verde-inteligente.git
   cd porto-verde-inteligente/backend
   ```
2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Execute o servidor:
   ```bash
   python server.py
   ```
4. Abra `frontend/index.html` no navegador.

---

## 🌎 Objetivos do projeto
- Tornar os dados ambientais acessíveis e transparentes.
- Auxiliar na tomada de decisão de gestores e comunidade.
- Promover o engajamento social e a sustentabilidade no Porto de Santos.

---

## 🧠 Autores
Equipe ADS - ESG Challenge 2025
