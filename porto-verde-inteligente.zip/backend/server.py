from flask import Flask, jsonify
import random

app = Flask(__name__)

@app.route('/api/sensores')
def sensores():
    dados = {
        'qualidade_ar': random.randint(50, 120),
        'ruido': random.randint(40, 90),
        'temperatura': random.uniform(20, 35)
    }
    return jsonify(dados)

if __name__ == '__main__':
    app.run(debug=True)